/** Automatically generated file. DO NOT MODIFY */
package com.example.mad2013_itslearning;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}