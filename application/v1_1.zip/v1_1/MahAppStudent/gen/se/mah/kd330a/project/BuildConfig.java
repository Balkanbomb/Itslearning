/** Automatically generated file. DO NOT MODIFY */
package se.mah.kd330a.project;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}